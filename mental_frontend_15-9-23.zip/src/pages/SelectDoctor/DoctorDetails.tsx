import Doctordetail from '../../components/Doctordetail'
const DoctorDetails = () => {
  return (
    <div className='d-flex justify-content-center m-4'>
      <Doctordetail/>
    </div>
  )
}

export default DoctorDetails
