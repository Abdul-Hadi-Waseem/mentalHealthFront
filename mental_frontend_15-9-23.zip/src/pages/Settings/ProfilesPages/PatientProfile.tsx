// import { useEffect, useState } from "react";
// import { useMatch, useNavigate } from "react-router-dom";
// import { appRoutes } from "../../../constants/constants";
// import "./Header.css";
// import Container from "react-bootstrap/Container";
// import Nav from "react-bootstrap/Nav";
// import Navbar from "react-bootstrap/Navbar";
// import dashboardIcon from "../../../assets/images/dashboardicon.png";
// // import myImage from "./../../../a"
// import myVisitsIcon from "../../../assets/images/myVisitsIcon.png";
// import prcsiptionIcon from "../../../assets/images/presciptionsIcon.png";
// import settingsIcon from "../../../assets/images/settingsIcon.png";
// import logoutIcon from "../../../assets/images/logoutIcon.svg";
// // import logo from "../../assets/images/logo.svg";
// import logo from "./../../../assets/images/logo.svg";
// import besse_cooper from "./../../../assets/images/besse_cooper.png";
// // import Button from "../Common/Buttons/Button";
// import Button from "../../../components/Common/Buttons/Button";
// import Cookies from "js-cookie";
import { getToken } from "../../../utils";
import { FaBell, FaChevronDown } from "react-icons/fa6";
import Avatar from "react-avatar";
import { Row, Col, Image } from "react-bootstrap";
import { useLocation } from "react-router-dom";
import Setting from "../Setting";

function PatientProfile() {
  

  return (
    <Setting>
     
    </Setting>
  );
}

export default PatientProfile;
