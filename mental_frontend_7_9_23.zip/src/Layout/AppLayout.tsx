import React from "react";
import Footer from "../components/Footer/Footer";
import Header from "../components/Header/Header";
import { useLocation } from "react-router-dom";

const AppLayout = ({ children }: { children: React.ReactNode }) => {
  const location = useLocation();

  const footerVisibleRoutes = [
    "/",
    "/blog-detail",
    "/contactUs",
    "/blog",
    "/whatWeTreat",
    "/about",
  ];
  const headerNotVisibleRoutes = [
    "/doctor-dashboard",
    "/upcoming-apointments",
    "/patients-history"
  ];

  const isFooterVisible = footerVisibleRoutes.includes(location.pathname);
  const isHeaderVisible = headerNotVisibleRoutes.includes(location.pathname)

  return (
    <>
      {!isHeaderVisible && <Header />}
      {children}
      {isFooterVisible && <Footer />}
    </>
  )
}

export default AppLayout
