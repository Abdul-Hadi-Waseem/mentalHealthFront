import doctor_img from "../assets/images/doctor.svg";
import DoctorCard from "./Common/DoctorCard";
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";
import Spinner from "react-bootstrap/Spinner";

const Selectdoctor = () => {
  // const [doctorProfiles, setdoctorProfiles] = useState([
  //   { name: "Bessie Cooper", designation: "Psychiatrist" },
  //   { name: "John Smith", designation: "Psychiatrist" },
  //   { name: "Shaen Watson", designation: "Psychiatrist" },
  // ]);
  const [doctorProfiles, setdoctorProfiles] = useState([]);

  useEffect(() => {
    try {
      const getAllDoctors = async () => {
        // console.log("url",process.env.URL)
        // console.log("url",process.env.NODE_ENV)
        // console.log("url",process.env.URL)
        let makeUrl:string ;
        makeUrl = "https://mental.cyclic.app";
        // makeUrl = "http://localhost:5000";
        // http://localhost:5000
        // https://mental.cyclic.app/
        const res = await axios.get(
          `${makeUrl}/doctor/get_all_doctors`
        );
        console.log("res", res.data.data[0]);
        Array.isArray(res.data);
        // setdoctorProfiles([{name:"fayyaz"}])
        setdoctorProfiles(res.data.data);
      };
      getAllDoctors();
    } catch (error) {
      console.log("error", error);
    }
  }, []);

  return (
    <>
      {doctorProfiles.length == 0 ? (
        <div
          className="d-flex justify-content-center align-items-center"
          style={{
            height: "90vh",
            width: "100%",
          }}
        >
          <Spinner
            animation="border"
            role="status"
            style={{ color: "#5E9CD3" }}
          >
            <span className="visually-hidden">Loading...</span>
          </Spinner>
        </div>
      ) : (
        <div className="select_doctorContainer">
          {doctorProfiles.map((item, index) => {
            return <DoctorCard doctor_details={{...item,designation: "Psychiatrist"}} img={doctor_img} />;
          })}
        </div>
      )}
    </>
  );
};

export default Selectdoctor;

// {/* <DoctorCard img={doctor_img}/>
// <DoctorCard img={doctor_img}/>
// <DoctorCard img={doctor_img}/>
// <DoctorCard img={doctor_img}/>
// <DoctorCard img={doctor_img}/>
// <DoctorCard img={doctor_img}/>
// <DoctorCard img={doctor_img}/> */}
