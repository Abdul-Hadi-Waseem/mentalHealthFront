import Selectdoctor from "../../components/Selectdoctor";
import "./selectDoctor.css";
import Header from "../PatientDashboard/Header/Header";
const SelectDoctor = () => {
  return (
    // <div className='d-flex justify-content-center m-4'>
    <Header>
      <Selectdoctor />
    </Header>
    // </div>
  );
};

export default SelectDoctor;
