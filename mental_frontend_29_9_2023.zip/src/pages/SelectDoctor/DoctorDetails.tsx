import Doctordetail from '../../components/Doctordetail'
import Header from '../PatientDashboard/Header/Header'
const DoctorDetails = () => {
  return (
    <Header
    //  className='d-flex justify-content-center m-4'
     >
      <Doctordetail/>
    </Header>
  )
}

export default DoctorDetails
