function Copyright () {
    return(
        <div className="copyright text-center">
        <p>© 2023 Mental Support.  All rights reserved, Privacy Policy and Terms of Use</p>
        </div>
    )
}

export default Copyright;