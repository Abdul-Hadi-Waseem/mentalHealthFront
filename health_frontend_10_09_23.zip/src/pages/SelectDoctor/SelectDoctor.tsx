import Selectdoctor from '../../components/Selectdoctor'
import "./selectDoctor.css"
const SelectDoctor = () => {
  return (
    <div className='d-flex justify-content-center m-4'>
      <Selectdoctor/>
    </div>
  )
}

export default SelectDoctor
