import { Col, Row } from "react-bootstrap";

// Components Login Sign-up and Registration
import Login from "../../components/Forms/Login";
import Registration from "../../components/Forms/Registration";
import DoctorLoginForm from "../../components/Forms/Doctors/DoctorLogin";
import DoctorRegistrationForm from "../../components/Forms/Doctors/DoctorRegistration";
import AcademicInformation from "../../components/Forms/Doctors/AcademicInformation";
import DoctorProfessionExperience from "../../components/Forms/Doctors/DoctorProfessionExperience";


import "./Account.css";
// images
import Login_Bg from "../../assets/images/login_bg.jpg";
import Register_Bg from "../../assets/images/register_bg.jpg";
import doctor_heart from "./../../assets/images/doctor_heart.png";
import doctor_login from "./../../assets/images/doctor_login.png";
import academic_information from "./../../assets/images/academic_information.png";
import professional_experience from "./../../assets/images/professional_experience.png";


function Account() {


  const goToPage = (path)=>{
    switch(path) {
      case "/login":
        return <Login />;
      case "/doctor-login":
        return <DoctorLoginForm />;
      case "/doctor-registration":
        return  <DoctorRegistrationForm />;
      case "/academic-information":
        return  <AcademicInformation />;
      case "/professional-experience":
        return  <DoctorProfessionExperience />;
      default:
        return <Registration />;
    }
  }

  const setImage = (path)=>{
    switch(path) {
      case "/login":
        return Login_Bg;
      case "/doctor-login":
        return doctor_login;
      case "/doctor-registration":
        return doctor_heart;
      case "/academic-information":
        return academic_information;
      case "/professional-experience":
        return professional_experience;
      default:
        return Register_Bg;
    }
  }




  return (
    <Row className="account__section g-0">
      <Col className="account__section__left" sm={12} lg={6}>
        {/* {location.pathname === "/login" ? <Login /> : location.pathname === "/doctor-login"? <DoctorRegistrationForm /> :<Registration />} */}
        {/* {location.pathname === "/login" ? (
          <Login />
        ) : location.pathname === "/doctor-login" ? (
          <DoctorLoginForm />
        ) : location.pathname === "/doctor-registration" ? (
          <DoctorRegistrationForm />
        ) : (
          <Registration />
        )} */}
        {goToPage(location.pathname)}
        <p className="copyright mb-5 text-center">
          © 2023 Mental Support. All rights reserved, Privacy Policy and Terms
          of Use
        </p>
      </Col>
      <Col className="d-flex"  sm={12} lg={6}>
        <img
          // src={location.pathname === "/login" ? Login_Bg :location.pathname === "/doctor-login" ? doctor_heart : Register_Bg}
          // location.pathname === "/login"
          //   ? Login_Bg
          //   : location.pathname === "/doctor-login"
          //   ? doctor_login
          //   : location.pathname === "/doctor-registration"
          //   ? doctor_heart
          //   : Register_Bg
          src={
            setImage(location.pathname)
          }
          className="w-100"
          style={{ height: "100%" }}
        />
      </Col>
    </Row>
  );
}

export default Account;
