import { Col, Row } from "react-bootstrap";
import Login from "../../components/Forms/Login";
import "./Account.css";
import Login_Bg from "../../assets/images/login_bg.jpg";
import Register_Bg from "../../assets/images/register_bg.jpg";
import Registration from "../../components/Forms/Registration";
import DoctorRegistrationForm from "../../components/Forms/Doctors/DoctorRegistration";
import doctor_heart from "./../../assets/images/doctor_heart.png";
import DoctorLoginForm from "../../components/Forms/Doctors/DoctorLogin";
import doctor_login from "./../../assets/images/doctor_login.png";

function Account() {
  return (
    <Row className="account__section g-0">
      <Col className="account__section__left" sm={12} lg={6}>
        {/* {location.pathname === "/login" ? <Login /> : location.pathname === "/doctor-login"? <DoctorRegistrationForm /> :<Registration />} */}
        {location.pathname === "/login" ? (
          <Login />
        ) : location.pathname === "/doctor-login" ? (
          <DoctorLoginForm />
        ) : location.pathname === "/doctor-registration" ? (
          <DoctorRegistrationForm />
        ) : (
          <Registration />
        )}
        <p className="copyright mb-5 text-center">
          © 2023 Mental Support. All rights reserved, Privacy Policy and Terms
          of Use
        </p>
      </Col>
      <Col style={{ height: "max-content" }} sm={12} lg={6}>
        <img
          // src={location.pathname === "/login" ? Login_Bg :location.pathname === "/doctor-login" ? doctor_heart : Register_Bg}
          src={
            location.pathname === "/login"
              ? Login_Bg
              : location.pathname === "/doctor-login"
              ? doctor_login
              : location.pathname === "/doctor-registration"
              ? doctor_heart
              : Register_Bg
          }
          className="w-100"
          style={{ height: "max-content" }}
        />
      </Col>
    </Row>
  );
}

export default Account;
