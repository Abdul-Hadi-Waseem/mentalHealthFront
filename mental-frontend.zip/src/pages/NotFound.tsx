function NotFound() {
  return (
    <>
      <p>NotFound</p>
    </>
  );
}

export default NotFound;
