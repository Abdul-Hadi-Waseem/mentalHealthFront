import doctor_img from '../assets/images/doctor.svg'
import DoctorCard from './Common/DoctorCard'
const Selectdoctor = () => {
  return (
    <div className="select_doctorContainer">
    <DoctorCard img={doctor_img}/>
    <DoctorCard img={doctor_img}/>
    <DoctorCard img={doctor_img}/>
    <DoctorCard img={doctor_img}/>
    <DoctorCard img={doctor_img}/>
    <DoctorCard img={doctor_img}/>
    <DoctorCard img={doctor_img}/>
    <DoctorCard img={doctor_img}/>
    </div>
  )
}

export default Selectdoctor
